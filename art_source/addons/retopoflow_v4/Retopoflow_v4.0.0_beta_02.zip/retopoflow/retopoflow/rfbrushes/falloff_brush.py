'''
Copyright (C) 2024 CG Cookie
http://cgcookie.com
hello@cgcookie.com

Created by Jonathan Denning, Jonathan Lampel

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import blf
import bmesh
import bpy
import gpu
import os
from itertools import chain
from random import random
from bmesh.types import BMVert, BMEdge, BMFace
from bpy_extras.view3d_utils import location_3d_to_region_2d
from mathutils import Vector, Matrix, Euler
from mathutils.bvhtree import BVHTree

import math
import time
from typing import List
from enum import Enum

from ..rftool_base import RFTool_Base
from ..rfbrush_base import RFBrush_Base
from ..common.bmesh import get_bmesh_emesh, NearestBMVert
from ..common.drawing import (
    Drawing,
    CC_2D_POINTS,
    CC_2D_LINES,
    CC_2D_LINE_STRIP,
    CC_2D_LINE_LOOP,
    CC_2D_TRIANGLES,
    CC_2D_TRIANGLE_FAN,
    CC_3D_TRIANGLES,
)
from ..common.icons import get_path_to_blender_icon
from ..common.operator import RFOperator, wrap_property, chain_rf_keymaps, execute_operator
from ..common.raycast import raycast_valid_sources, raycast_point_valid_sources, size2D_to_size, size2D_to_size_point, vec_forward, mouse_from_event
from ..common.maths import view_forward_direction, lerp
from ...addon_common.common import bmesh_ops as bmops
from ...addon_common.common.blender_cursors import Cursors
from ...addon_common.common.maths import Color, Frame, clamp
from ...addon_common.common.blender import get_path_from_addon_common
from ...addon_common.common import gpustate
from ...addon_common.common.colors import Color4
from ...addon_common.common.maths import clamp, Direction, Vec, Point, Point2D, Vec2D
from ...addon_common.common.utils import iter_pairs
from ...addon_common.common.timerhandler import TimerHandler


def create_falloff_brush(idname, label, **kwargs):
    class RFBrush_Falloff(RFBrush_Base):
        # brush settings
        radius   = kwargs.get('radius',   200)
        falloff  = kwargs.get('falloff',  1.5)
        strength = kwargs.get('strength', 0.75)

        # brush visualization settings
        fill_color      = kwargs.get('fill_color',  Color.from_ints(0, 135, 255, 255))
        outer_color     = Color((1,1,1,1))     # outer circle
        inner_color     = Color((1,1,1,0.5))   # inner circle
        min_color       = Color((1,1,1,0.5))   # tiny circle at very center (only when adjusting)
        below_alpha     = Color((1,1,1,0.25))  # multiplied against fill_color when occluded
        brush_min_alpha = 0.100
        brush_max_alpha = 0.700
        depth_fill      = 0.998 # see note on gl_FragDepth in circle_3D.glsl
        depth_border    = 0.996 # see note on gl_FragDepth in circle_3D.glsl

        # hack to know which areas the mouse is in
        mouse_areas = set()

        operator = None

        @classmethod
        def set_operator(cls, operator):
            cls.operator = operator

        @classmethod
        def is_top_modal(cls, context):
            op_name = cls.operator.bl_label
            ops = context.window.modal_operators
            if ops[0].name == op_name: return True
            if len(ops) >= 2 and ops[0].name == 'Screencast Keys' and ops[1].name == op_name: return True
            return False

        def init(self):
            self.mouse = None
            self.hit = False
            self.hit_p = None
            self.hit_n = None
            self.hit_scale = None
            self.hit_depth = None
            self.hit_x = None
            self.hit_y = None
            self.hit_z = None
            self.hit_rmat = None


        def get_scaled_radius(self):
            return self.hit_scale * self.radius
        def get_strength_dist(self, dist:float):
            return self.strength * clamp(1.0 - math.pow(dist / self.get_scaled_radius(), self.falloff), 0.0, 1.0)
        def get_strength_Point(self, point:Point):
            if not self.hit_p: return 0.0
            return self.get_strength_dist((point - self.hit_p).length)

        def update(self, context, event):
            if not RFBrush_Falloff.operator: return
            if event.type != 'MOUSEMOVE': return

            mouse = mouse_from_event(event)

            if RFBrush_Falloff.operator.is_active() or RFOperator_FalloffBrush_Adjust.is_active():
                active_op = RFOperator.active_operator()
                # artist is actively brushing or adjusting brush properties, so always consider us inside if we're in the same area
                mouse_inside = (context.area == active_op.working_area) and (context.window == active_op.working_window)
            else:
                mouse_inside = (0 <= mouse[0] < context.area.width) and (0 <= mouse[1] < context.area.height)

            if not mouse_inside:
                if context.area in self.mouse_areas:
                    # we were inside this area, but not anymore.  tag for redraw to remove brush
                    self.mouse_areas.remove(context.area)
                    context.area.tag_redraw()
                return

            if context.area not in self.mouse_areas:
                # we were outside this area before, but now we're in
                self.mouse_areas.add(context.area)

            self.mouse = mouse
            context.area.tag_redraw()

        def _update(self, context):
            if context.area not in self.mouse_areas: return
            self.hit = False
            if not self.mouse: return
            # print(f'RFBrush_Falloff.update {(event.mouse_region_x, event.mouse_region_y)}') #{context.region=} {context.region_data=}')
            hit = raycast_valid_sources(context, self.mouse)
            # print(f'  {hit=}')
            if not hit: return
            #scale = size2D_to_size_point(context, self.mouse, hit['co_world'])
            self.offset = min(hit['distance'] * 0.75, 1.05 * context.space_data.overlay.retopology_offset)
            scale = size2D_to_size(context, hit['distance'], pt=self.mouse)
            scale_offset = size2D_to_size(context, hit['distance'] - self.offset, pt=self.mouse)
            # print(f'  {scale=}')
            if scale is None or scale_offset is None: return

            n = hit['no_local']
            rmat = Matrix.Rotation(Direction.Z.angle(n), 4, Direction.Z.cross(n))

            self.hit = True
            self.hit_ray = hit['ray_world']
            self.hit_scale = scale
            self.hit_scale_offset = scale_offset
            self.hit_p = hit['co_world']
            self.hit_n = hit['no_world']
            self.hit_depth = hit['distance']
            self.hit_x = Vec(rmat @ Direction.X)
            self.hit_y = Vec(rmat @ Direction.Y)
            self.hit_z = Vec(rmat @ Direction.Z)
            self.hit_rmat = rmat

        def draw_postpixel(self, context):
            if not RFBrush_Falloff.operator: return
            if context.area not in self.mouse_areas: return
            if not RFOperator_FalloffBrush_Adjust.is_active(): return
            
            if RFBrush_Falloff.operator.is_active() or RFOperator_FalloffBrush_Adjust.is_active():
                active_op = RFOperator.active_operator()
            else:
                active_op = None
            adjust = active_op.adjust if active_op is not None else ''

            center2D = self.center2D

            r = self.radius if adjust == 'RADIUS' else context.region.height * 0.25 * 0.5
            co, ci, cf = self.outer_color, self.inner_color, self.fill_color # * fillscale
            cm = self.min_color

            # Inner radius should be based on strength instead of falloff
            # Clamp inner radius between min_radius (0.24*r) and outer radius (r)
            min_radius = 0.24 * r
            # With inverted mapping: strength 0.0 → min_radius, strength 1.0 → max_radius
            inner_radius = min_radius + self.strength * (r - min_radius)
            
            # Calculate falloff for filled area
            ff = math.pow(0.5, 1.0 / max(self.falloff, 0.0001))
            fs = (1-ff) * self.radius
            gpustate.blend('ALPHA')
            
            text_value = None

            # Draw - falloff - filled circle ring
            if adjust == 'FALLOFF':
                # Draw circle (40% of radius) for brush-falloff reference for 0.0-2.0 range reference.
                Drawing.draw2D_smooth_circle(context, center2D, r * 0.4, cf, width=0.5)
                text_value = f"{round(self.falloff, 2)}"
                gradient_factor = 1.0 - self.falloff / 100
                if gradient_factor <= 0.01:
                    gradient_factor = 0.01
                fillscale = Color((1, 1, 1, lerp(self.strength * clamp(self.falloff, 0.0, 1.0), self.brush_min_alpha, self.brush_max_alpha)))
                Drawing.draw2D_smooth_circle(context, center2D, r, cf * fillscale, width=0, smooth_threshold=r*gradient_factor)

            if adjust == 'RADIUS':
                Drawing.draw2D_smooth_circle(context, center2D, active_op.prev_radius, cf, width=0.5)

            # Draw outer - brush radius - circle border
            Drawing.draw2D_smooth_circle(context, center2D, r, cf, width=2 if adjust == 'RADIUS' else 0.5)

            if adjust == 'STRENGTH':
                # Draw inner - strength-based - circle border
                Drawing.draw2D_smooth_circle(context, center2D, inner_radius, cf, width=2)
                # Draw minimum circle (10% of radius) for brush-trength control.
                Drawing.draw2D_smooth_circle(context, center2D, min_radius, cf, width=0.5)
                
                text_value = f"{round(self.strength, 2)}"
                
            if text_value:
                text_w = Drawing.get_text_width(text_value)
                text_h = Drawing.get_line_height(text_value)
                Drawing.text_draw2D_simple(text_value, center2D + Vector((-text_w, text_h)) * 0.5)

            # Draw center dot (well, skipping it since Blender brushes does not draw this).
            # Drawing.draw2D_circle(context, center2D, 2, cm, width=1)

        def draw_postview(self, context):
            if context.area not in self.mouse_areas: return
            if RFOperator_FalloffBrush_Adjust.is_active(): return
            if not self.RFCore or not (self.RFCore.is_top_modal(context) or self.is_top_modal(context)): return
            self._update(context)
            if not self.hit or self.hit_n is None: return # Ensure we have a hit and a normal

            # Calculate position and orientation
            p = self.hit_p - self.hit_ray[1].xyz * self.offset
            n = self.hit_n
            
            # Calculate outer radius based on actual brush radius and scale
            ro = self.radius
            
            # Calculate minimum radius (24% of outer radius)
            rmin = 0.24 * ro
            
            # Calculate inner radius based on strength
            # Map strength 0.0 → min_radius, strength 1.0 → outer_radius
            ri = rmin + self.strength * (ro - rmin)
            
            # Colors (now using fill color)
            co, ci = self.fill_color, self.fill_color  # self.outer_color, self.inner_color
            # Ensure below_alpha has alpha component 'a'
            below_alpha_val = self.below_alpha.a if hasattr(self.below_alpha, 'a') else self.below_alpha[3] if isinstance(self.below_alpha, (list, tuple)) and len(self.below_alpha) == 4 else 0.25

            gpustate.blend('ALPHA')
            gpustate.depth_mask(True) # Keep depth mask enabled
            
            viewport_size = (context.region.width, context.region.height)

            # draw above
            gpustate.depth_test('LESS_EQUAL')
            Drawing.draw_circle_3d(position=p, normal=n, color=co, radius=ro, thickness=2, scale=self.hit_scale_offset, segments=None, viewport_size=viewport_size)
            Drawing.draw_circle_3d(position=p, normal=n, color=ci, radius=ri, thickness=1, scale=self.hit_scale_offset, segments=None, viewport_size=viewport_size)

            # draw below
            gpustate.depth_test('GREATER')
            # Adjust alpha for drawing below
            co_below = Color((*co[:3], co.a * below_alpha_val))
            ci_below = Color((*ci[:3], ci.a * below_alpha_val))
            Drawing.draw_circle_3d(position=p, normal=n, color=co_below, radius=ro, thickness=2, scale=self.hit_scale_offset, segments=None, viewport_size=viewport_size)
            Drawing.draw_circle_3d(position=p, normal=n, color=ci_below, radius=ri, thickness=1, scale=self.hit_scale_offset, segments=None, viewport_size=viewport_size)

            # reset
            gpustate.depth_test('LESS_EQUAL')
            # gpustate.depth_mask(False) # Optionally disable depth mask if needed after drawing

    class RFOperator_FalloffBrush_Adjust(RFOperator):
        bl_idname      = f'retopoflow.{idname}'
        bl_label       = label
        bl_description = f'Adjust properties of {label}'
        bl_space_type  = 'VIEW_3D'
        bl_space_type  = 'TOOLS'
        bl_options     = set()

        rf_keymaps = [
            # see hacks below
            (f'retopoflow.{idname}_radius',   {'type': 'F', 'value': 'PRESS', 'ctrl': 0, 'shift': 0}, None),
            (f'retopoflow.{idname}_falloff',  {'type': 'F', 'value': 'PRESS', 'ctrl': 1, 'shift': 0}, None),
            (f'retopoflow.{idname}_strength', {'type': 'F', 'value': 'PRESS', 'ctrl': 0, 'shift': 1}, None),
        ]
        rf_status = ['LMB: Commit', 'RMB: Cancel']

        adjust: bpy.props.EnumProperty(
            name=f'{label} Property',
            description=f'Property of {label} to adjust',
            items=[
                ('NONE',     'None',     f'Adjust Nothing',              -1), # prevents default
                ('RADIUS',   'Radius',   f'Adjust {label} Radius',    0),
                ('STRENGTH', 'Strength', f'Adjust {label} Strength',  1),
                ('FALLOFF',  'Falloff',  f'Adjust {label} Falloff',   2),
            ],
            default='NONE',
        )
        
        #################################################################################
        # these are hacks to launch falloff brush operator with certain set properties
        @staticmethod
        @execute_operator(f'{idname}_radius',   f'Adjust {label} Radius')
        def adjust_radius(context):
            op = getattr(bpy.ops.retopoflow, f'{idname}')
            op('INVOKE_DEFAULT', adjust='RADIUS')
        @staticmethod
        @execute_operator(f'{idname}_strength', f'Adjust {label} Strength')
        def adjust_strength(context):
            op = getattr(bpy.ops.retopoflow, f'{idname}')
            op('INVOKE_DEFAULT', adjust='STRENGTH')
        @staticmethod
        @execute_operator(f'{idname}_falloff',  f'Adjust {label} Falloff')
        def adjust_falloff(context):
            op = getattr(bpy.ops.retopoflow, f'{idname}')
            op('INVOKE_DEFAULT', adjust='FALLOFF')
        #################################################################################

        def get_vis_radius(self, context):
            return context.region.height * 0.25 * 0.5

        def dist_to_radius(self, d, context=None):
            RFBrush_Falloff.radius = max(5, int(d))
        def radius_to_dist(self, context=None):
            return RFBrush_Falloff.radius
        def dist_to_strength(self, d, context):
            # Use visualization radius instead of actual brush radius
            vis_radius = self.get_vis_radius(context)
            min_radius = 0.24 * vis_radius
            max_radius = vis_radius
            
            # Map distance d to a strength value:
            # - When d is near min_radius, strength should be 0.0
            # - When d is near max_radius, strength should be 1.0
            # - Ensure that at max_radius we get exactly 1.0
            normalized_dist = clamp((d - min_radius) / (max_radius - min_radius), 0.0, 1.0)
            RFBrush_Falloff.strength = normalized_dist
            
        def strength_to_dist(self, context):
            # Use visualization radius instead of actual brush radius
            vis_radius = self.get_vis_radius(context)
            min_radius = 0.24 * vis_radius
            max_radius = vis_radius
            # Convert strength to distance based on the same mapping:
            # strength 0.0 → min_radius, strength 1.0 → max_radius
            return min_radius + RFBrush_Falloff.strength * (max_radius - min_radius)
            
        def dist_to_falloff(self, d, context):
            # Use visualization radius instead of actual brush radius
            vis_radius = self.get_vis_radius(context)
            
            # Normalize distance as percentage of visualization radius (0.0 to 1.0)
            norm_dist = clamp(d / vis_radius, 0.0, 1.0)
            
            # Apply non-linear mapping:
            # - First 40% of radius maps to falloff values 0.0-1.0
            # - Remaining 60% of radius maps to falloff values 1.0-100.0
            # - Ensure that at radius (norm_dist = 1.0) we get exactly 100.0
            if norm_dist <= 0.4:
                # Map 0.0-0.4 to 0.0-1.0
                RFBrush_Falloff.falloff = (norm_dist / 0.4) * 1.0
            else:
                # Map 0.4-1.0 to 1.0-100.0
                normalized_remaining = (norm_dist - 0.4) / 0.6  # Normalize the remaining distance
                RFBrush_Falloff.falloff = 1.0 + (normalized_remaining * 98.0)  # Map to 1.0-100.0
                
        def falloff_to_dist(self, context):
            # Use visualization radius instead of actual brush radius
            vis_radius = self.get_vis_radius(context)
            
            # Apply inverse mapping to convert falloff back to distance
            falloff = RFBrush_Falloff.falloff
            
            if falloff <= 1.0:
                # Map 0.0-1.0 to 0.0-0.4 of radius
                normalized_dist = (falloff / 1.0) * 0.4
            else:
                # Map 1.0-100.0 to 0.4-1.0 of radius
                normalized_dist = 0.4 + ((falloff - 1.0) / 98.0) * 0.6
                
            return normalized_dist * vis_radius

        def can_init(self, context, event):
            if self.adjust == 'NONE': return False

        def init(self, context, event):
            match self.adjust:
                case 'RADIUS':
                    self._dist_to_var_fn = self.dist_to_radius
                    self._var_to_dist_fn = self.radius_to_dist
                case 'STRENGTH':
                    self._dist_to_var_fn = self.dist_to_strength
                    self._var_to_dist_fn = self.strength_to_dist
                case 'FALLOFF':
                    self._dist_to_var_fn = self.dist_to_falloff
                    self._var_to_dist_fn = self.falloff_to_dist
                case _:
                    assert False, f'Unhandled {self.adjust=}'

            # Get the initial value and convert it to distance
            dist = self._var_to_dist_fn(context)
            
            # Store the initial radius for radius adjustment
            self.prev_radius = RFBrush_Falloff.radius
            
            # Store the initial value for potential cancellation
            self._change_pre = dist
            
            # Get the mouse position
            mouse = Point2D((event.mouse_region_x, event.mouse_region_y))
            
            # Set the center point for the adjustment
            # For radius adjustment, we want to start from the current radius
            # For strength and falloff, we want to start from the current value's position
            if self.adjust == 'RADIUS':
                RFBrush_Falloff.center2D = mouse - Vec2D((dist, 0))
            else:
                # For strength and falloff, calculate the center based on the current value
                # This ensures that moving to the edge will reach the maximum value
                angle = 0.0  # We'll use horizontal direction for consistency
                RFBrush_Falloff.center2D = mouse - Vec2D((dist * math.cos(angle), dist * math.sin(angle)))
            
            context.area.tag_redraw()

        def update(self, context, event):
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                return {'FINISHED'}
            if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
                self._dist_to_var_fn(self._change_pre, context)
                return {'CANCELLED'}
            if event.type == 'ESC' and event.value == 'PRESS':
                self._dist_to_var_fn(self._change_pre, context)
                return {'CANCELLED'}

            if event.type == 'MOUSEMOVE':
                mouse = Point2D((event.mouse_region_x, event.mouse_region_y))
                
                # Calculate distance from center to mouse
                dist = (RFBrush_Falloff.center2D - mouse).length
                
                # For radius adjustment, we want to use the raw distance
                # For strength and falloff, we want to ensure we can reach the maximum value
                if self.adjust != 'RADIUS':
                    # For strength and falloff, we want to ensure that reaching the edge
                    # of the circle gives us the maximum value
                    max_dist = self.get_vis_radius(context)
                    dist = min(dist, max_dist)

                self._dist_to_var_fn(dist, context)
                context.area.tag_redraw()
                return {'PASS_THROUGH'}

            return {'RUNNING_MODAL'} # allow other operators, such as UNDO!!!

    return (RFBrush_Falloff, RFOperator_FalloffBrush_Adjust)